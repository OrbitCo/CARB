﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CAQM.Entities;

namespace CAQM.IServices
{
    public interface IUserDocumentService
    {
        UsersDocument GetById(int userId, string filename);
        UsersDocument Create(UsersDocument usersDocument);
        void Delete(int id);
    }

    
}
