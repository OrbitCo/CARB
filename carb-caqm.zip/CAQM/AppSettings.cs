namespace CAQM
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}